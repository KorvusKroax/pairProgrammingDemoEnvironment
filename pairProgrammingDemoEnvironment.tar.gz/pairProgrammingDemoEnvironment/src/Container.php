<?php

class Container
{
    private $configuration;
    private array $instances;

    public function __construct(array $configuration)
    {
        $this->configuration = $configuration;
        $this->instances = [];
    }

    public function get($serviceId)
    {
        $argum = $this->configuration['services'][$serviceId]['arguments'] ?? [];
        if (!isset($this->instances[$serviceId])) {

          foreach($argum as $index => $arg) {
            if (strpos($arg, '@') === 0) {
              $argum[$index] = $this->get(substr($arg, 1));
            }
          }

          $new_class =  $this->configuration['services'][$serviceId]['class'];
          $this->instances[$serviceId] =
            new $new_class(
              ...$argum
            );
        }

        return $this->instances[$serviceId];
    }

    public function getParameter($parameterName)
    {
        return $this->configuration['parameters'][$parameterName] ?? null;
    }
}


/*
foreach ($arr as $index => $ertek) {
  $arr[$index] = -1 * $ertek;
}
*/
