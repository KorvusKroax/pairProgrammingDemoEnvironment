<?php

class Proba
{
    public function getHelloWorld() : string
    {
        return 'Hello World!';
    }
}
