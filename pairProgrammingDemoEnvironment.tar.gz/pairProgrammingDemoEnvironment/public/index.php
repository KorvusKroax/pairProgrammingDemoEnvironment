<?php
require('../src/Proba.php');
$p = new Proba();
echo $p->getHelloWorld();
